const express = require("express")
const path = require("path")

const app = express()

// Pasta pública
app.use(express.static(path.join(__dirname, "public")))

// Rotas HTML
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"))
})

app.get("/cobra", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "cobra.html"))
})

app.get("/devs", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "devs.html"))
})

// Servidor
app.listen(3000, () => {
    console.log("Servidor rodando em http://localhost:3000")
})