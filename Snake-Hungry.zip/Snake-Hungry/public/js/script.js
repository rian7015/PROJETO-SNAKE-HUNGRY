const canvas = document.querySelector("canvas")
const ctx = canvas.getContext("2d")

/* ELEMENTOS DA INTERFACE*/
const score = document.querySelector(".score--value")
const finalScore = document.querySelector(".final-score > span")
const menu = document.querySelector(".menu-screen")
const buttonPlay = document.querySelector(".btn-play")
const highScoreElement = document.querySelector(".high-score")

/* CONFIGURAÇÕES DO JOGO*/

// Tamanho de cada bloco
const size = 30
// Posição inicial da cobra
const initialPosition = { x: 270, y: 240 }
// Velocidade inicial
const initialSpeed = 400
// Velocidade atual
let speed = initialSpeed
// Array da cobra
let snake = [initialPosition]
// Direção da cobra
let direction
// ID do loop do jogo
let loopId
// Obstáculos
let obstacles = []

/*SISTEMA DE PONTUAÇÃO*/

// Aumenta a pontuação
const incrementScore = () => {
    score.innerText = +score.innerText + 10
}

/*SISTEMA DE RANKING*/

// Atualiza recorde
const updateHighScore = () => {
    const current = +score.innerText
    const saved = localStorage.getItem("highScore") || 0
    const best = current > saved ? current : saved
    localStorage.setItem("highScore", best)
    if (highScoreElement) {
        highScoreElement.innerText = best
    }
}
// Mostra recorde ao iniciar
if (highScoreElement) {
    highScoreElement.innerText = localStorage.getItem("highScore") || 0
}

const randomNumber = (min, max) =>
    Math.round(Math.random() * (max - min) + min)

const randomPosition = () => {
    const number = randomNumber(0, canvas.width - size)
    return Math.round(number / size) * size
}
// Cor aleatória
const randomColor = () =>
    `rgb(${randomNumber(0,255)},${randomNumber(0,255)},${randomNumber(0,255)})`

/*COMIDA*/

// Objeto da comida
const food = {
    x: randomPosition(),
    y: randomPosition(),
    color: randomColor()
}

/*OBSTÁCULOS*/

// Gera obstáculos
const generateObstacles = () => {
    obstacles = []
    while (obstacles.length < 7) {
        let x = randomPosition()
        let y = randomPosition()
        const overlap =
            snake.some(p => p.x === x && p.y === y) ||
            (food.x === x && food.y === y) ||
            obstacles.some(o => o.x === x && o.y === y)
        if (!overlap) obstacles.push({ x, y })
    }
}

/* FUNÇÕES DE DESENHO**/

// Desenha comida
const drawFood = () => {
    ctx.fillStyle = food.color
    ctx.fillRect(food.x, food.y, size, size)
}
// Desenha obstáculos
const drawObstacles = () => {
    ctx.fillStyle = "red"
    obstacles.forEach(o => ctx.fillRect(o.x, o.y, size, size))
}
// Desenha cobra
const drawSnake = () => {
    snake.forEach((pos, i) => {
        ctx.fillStyle = i === snake.length - 1 ? "white" : "#ddd"
        ctx.fillRect(pos.x, pos.y, size, size)
    })
}
/*Desenha grade*/
const drawGrid = () => {
    ctx.strokeStyle = "#191919"
    for (let i = size; i < canvas.width; i += size) {
        ctx.beginPath()
        ctx.moveTo(i, 0)
        ctx.lineTo(i, canvas.height)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(0, i)
        ctx.lineTo(canvas.width, i)
        ctx.stroke()
    }
}

/* MOVIMENTO DA COBRA*/

// Move a cobra
const moveSnake = () => {
    if (!direction) return
    const head = snake[snake.length - 1]
    let newHead = { x: head.x, y: head.y }
    if (direction === "right") newHead.x += size
    if (direction === "left") newHead.x -= size
    if (direction === "down") newHead.y += size
    if (direction === "up") newHead.y -= size
    snake.push(newHead)
    // Remove cauda se não comer
    if (!(newHead.x === food.x && newHead.y === food.y)) {
        snake.shift()
    }
}

/* VERIFICA SE COMEU*/

const checkEat = () => {
    const head = snake[snake.length - 1]
    if (head.x === food.x && head.y === food.y) {
        incrementScore()
        // Aumenta velocidade
        speed = Math.max(100, speed - 10)
        let x, y
        do {
            x = randomPosition()
            y = randomPosition()
        } while (
            snake.some(p => p.x === x && p.y === y) ||
            obstacles.some(o => o.x === x && o.y === y)
        )
        food.x = x
        food.y = y
        food.color = randomColor()
    }
}

/* VERIFICA COLISÕES*/

const checkCollision = () => {
    const head = snake[snake.length - 1]
    const limit = canvas.width - size
    // Parede
    const wall =
        head.x < 0 || head.x > limit || head.y < 0 || head.y > limit
    // Corpo
    const self = snake
        .slice(0, -1)
        .some(p => p.x === head.x && p.y === head.y)
    // Obstáculos
    const obstacle = obstacles.some(
        o => o.x === head.x && o.y === head.y
    )
    // Encerra jogo
    if (wall || self || obstacle) gameOver()
}

/*GAME OVER*/

const gameOver = () => {
    clearTimeout(loopId)
    direction = undefined
    updateHighScore()
    menu.style.display = "flex"
    finalScore.innerText = score.innerText
    // Blur no canvas
    canvas.style.filter = "blur(2px)"
}

/* LOOP PRINCIPAL*/

// Função principal
const gameLoop = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawGrid()
    drawFood()
    drawObstacles()
    moveSnake()
    drawSnake()
    checkEat()
    checkCollision()
    loopId = setTimeout(gameLoop, speed)
}

/*INICIA O JOGO*/
generateObstacles()
gameLoop()

/* CONTROLES DO TECLADO*/
document.addEventListener("keydown", (event) => {

    // Impede rolagem
    if (
        event.key === "ArrowRight" ||
        event.key === "ArrowLeft" ||
        event.key === "ArrowDown" ||
        event.key === "ArrowUp"
    ) {
        event.preventDefault()
    }
    const key = event.key
    // Direções válidas
    if (key === "ArrowRight" && direction !== "left") direction = "right"
    if (key === "ArrowLeft" && direction !== "right") direction = "left"
    if (key === "ArrowDown" && direction !== "up") direction = "down"
    if (key === "ArrowUp" && direction !== "down") direction = "up"
})

/* RESET DO JOGO */
buttonPlay.addEventListener("click", () => {

    // Para loop antigo
    clearTimeout(loopId)
    // Reseta placar
    score.innerText = "00"
    // Esconde menu
    menu.style.display = "none"
    // Remove blur
    canvas.style.filter = "none"
    // Reseta cobra
    snake = [initialPosition]
    // Remove direção
    direction = undefined
    // Reseta velocidade
    speed = initialSpeed
    // Novos obstáculos
    generateObstacles()
    // Reinicia jogo
    gameLoop()
})